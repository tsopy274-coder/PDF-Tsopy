# PDF-Tsopy — Website redesign

Ανανεωμένη, responsive ιστοσελίδα παρουσίασης του PDF Tsopy.

## Περιεχόμενα
- `index.html` — νέα ιστοσελίδα με φωτεινό premium design
- Γλώσσες: Ελληνικά, Αγγλικά, Γαλλικά, Γερμανικά
- Σύνδεσμοι λήψης και GitHub
- Responsive εμφάνιση για κινητά, tablet και υπολογιστές

## Εγκατάσταση στο GitHub Pages
1. Άνοιξε το repository `PDF-Tsopy` στο GitHub.
2. Αντικατάστησε το υπάρχον `index.html` με το νέο αρχείο.
3. Κάνε Commit changes.
4. Περίμενε να ολοκληρωθεί το GitHub Pages deployment και κάνε ανανέωση στη σελίδα.

Η εφαρμογή PDF και τα αρχεία της δεν αλλάζουν. Αλλάζει μόνο η ιστοσελίδα παρουσίασης.
